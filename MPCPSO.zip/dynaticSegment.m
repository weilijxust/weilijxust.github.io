function pbest = dynaticSegment(i,t,G,D,x,f,pb)
 %����ά��Ƭ��
dm=ceil(t/G*D);            % ά�ȷֶ�����
quotient=floor(D/dm);      % һ���ֶΰ�����ά����
remainder =mod(D,dm);      % ʣ��ά���� 
[row,col]=size(x);
for j=1:quotient:D
    for p=1:2
        n1=randi(row);
        n2=randi(row);
        while n1==n2
            n1=randi(row);
            n2=randi(row);
        end
        if f(n1)<f(n2)
            rst(p)=n1;
        else
            rst(p)=n2;
        end
    end
    fit=f(rst(1))+f(rst(2));
    if j+quotient-1>D
        for k=D-remainder +1:D
            mbest(1,k)=0;
            for h=1:2
                mbest(1,k)=mbest(1,k)+f(rst(h))/fit*x(rst(h),k);
            end
            mbest(1,k)=mbest(1,k)/2;
            pb(i,k)=mbest(1,k);  
        end 
    else
       for k=j:j+quotient-1
            mbest2(1,k)=0;
            for h=1:2
                mbest2(1,k)=mbest2(1,k)+f(rst(h))/fit*x(rst(h),k);
            end
            mbest2(1,k)=mbest2(1,k)/2;
            pb(i,k)=mbest2(1,k);  
        end 
    end 
end
pbest = pb;
end